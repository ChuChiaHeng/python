# 你有以下清單結構:
alph = "abcdefghijklmnopqrstuvwxyz"
'''
A. zwtqnkheb
B. pmjg
C. defghijklmno
D. ponmlkjihgfe
E. defghijklmnop
F. dgjm
G. olif
回答區, 請將正確答案代號(A~G)填入第(1)~(4)題
()(1) alph[3:15]
()(2) alph[3:15:3]
()(3) alph[15:3:-3]
()(4) alph[::-3]
'''